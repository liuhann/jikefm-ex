package com.sinosoft.android.graphics.thumbnail;

/**
 * Created by jacking on 2014/9/16.
 */
public class TargetPathNotFoundException extends RuntimeException {

    public TargetPathNotFoundException() {
    }

    public TargetPathNotFoundException(Throwable cause) {
        super(cause);
    }
}
