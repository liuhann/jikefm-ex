package com.sinosoft.android.graphics.thumbnail;

/**
 * Created by jacking on 2014/9/16.
 */
public class SourcePathNotFoundException extends RuntimeException {

    public SourcePathNotFoundException() {
    }

    public SourcePathNotFoundException(Throwable cause) {
        super(cause);
    }
}
